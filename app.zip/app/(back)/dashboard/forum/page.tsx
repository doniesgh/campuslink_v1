import { useCallback, useState } from 'react';
import PostsLayout from '@/layouts/PostsLayout';
import PostToolbar from '@/components/feed/PostToolbar';
import PostFeed from '@/components/feed/PostFeed';
import PostFormModal from '@/components/form/PostFormModal';
import PostDetailModal from '@/components/detail/PostDetailModal';
import { usePosts } from '@/hooks/usePosts';

interface Props {
  /** id of the logged-in user (used for likes and ownership checks) */
  currentUserId: string;
}

export default function PostsPage({ currentUserId }: Props) {
  const feed = usePosts(currentUserId);
  const [creating, setCreating] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);

  const closeCreate = useCallback(() => setCreating(false), []);
  const closeDetail = useCallback(() => setOpenId(null), []);

  return (
    <PostsLayout
      title="Community"
      subtitle="Carpooling, lost & found, experiences and ideas."
      // actions={<Button onClick={() => setCreating(true)}>＋ New post</Button>}
    >
      <PostToolbar
        type={feed.type} onTypeChange={feed.setType}
        search={feed.search} onSearchChange={feed.setSearch}
        status={feed.status} onStatusChange={feed.setStatus}
      />

      <PostFeed
        posts={feed.posts}
        loading={feed.loading}
        error={feed.error}
        likedIds={feed.likedIds}
        page={feed.page}
        pages={feed.pages}
        onPageChange={feed.setPage}
        onOpen={setOpenId}
        onLike={feed.toggleLike}
      />

      {creating && <PostFormModal onClose={closeCreate} onSubmit={feed.createPost} />}
      {openId && (
        <PostDetailModal
          postId={openId}
          currentUserId={currentUserId}
          onClose={closeDetail}
          onChanged={feed.reload}
        />
      )}
    </PostsLayout>
  );
}
