// Full class strings (not built dynamically) so Tailwind's JIT can detect them.
export const POST_TYPES = {
  covoiturage: {
    label: 'Carpooling',
    icon: '🚗',
    badge: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  },
  objet_perdu: {
    label: 'Lost & found',
    icon: '🔎',
    badge: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  },
  experience: {
    label: 'Experience',
    icon: '💬',
    badge: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  },
  idee: {
    label: 'Idea',
    icon: '💡',
    badge: 'bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-500/15 dark:text-fuchsia-300',
  },
};

export const STATUSES = {
  active: {
    label: 'Active',
    badge: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300',
  },
  closed: {
    label: 'Closed',
    badge: 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300',
  },
  resolved: {
    label: 'Resolved',
    badge: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  },
};

export const LOST_KINDS = {
  perdu: 'I lost something',
  trouve: 'I found something',
};

export const LOST_CATEGORIES = [
  'Keys', 'Phone', 'Documents', 'Wallet', 'Bag', 'Clothes', 'Jewelry', 'Other',
];
