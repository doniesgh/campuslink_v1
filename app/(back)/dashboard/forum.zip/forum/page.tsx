
import type { Metadata } from "next";
import { AddPostButton } from "@/components/forum/add-post-button";
import { Feed } from "@/components/forum/feed";
import { MySpaceLink } from "@/components/forum/my-space-link";
import { NearbyLink } from "@/components/forum/nearby-link";
import { SearchRideLink } from "@/components/forum/search-ride-link";
import { CommentIcon, IconCircle } from "@/components/forum/icons";
import { S } from "@/lib/forum/strings";

export const metadata: Metadata = { title: S.title };

export default function PostsPage() {
  // return (
  //   <div className="container pb-28 pt-9 sm:pt-10">
  //     <header className="mx-auto flex max-w-xl flex-col items-center text-center">
  //       <IconCircle tone="brand" size="lg" className="size-14 ring-4 ring-primary/15 [&>svg]:size-7">
  //         <CommentIcon />
  //       </IconCircle>
  //       <h1 className="mt-3 text-2xl font-semibold">{S.title}</h1>
  //       <p className="mt-1 text-sm text-muted-foreground">{S.subtitle}</p>
  //       <div className="mt-4 flex flex-wrap justify-center gap-2"><NearbyLink /><MySpaceLink /></div>
  //     </header>
  //     <Feed />
  //     <AddPostButton />
  //   </div>
  // );
   return (
    <div className="container pb-28 pt-9 sm:pt-10">
      <header className="mx-auto flex max-w-xl flex-col items-center text-center">
        <IconCircle tone="brand" size="lg" className="size-14 ring-4 ring-primary/15 [&>svg]:size-7">
          <CommentIcon />
        </IconCircle>
        <h1 className="mt-3 text-2xl font-semibold">{S.title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{S.subtitle}</p>
        <div className="mt-4 flex flex-wrap justify-center gap-2"><NearbyLink /><SearchRideLink /><MySpaceLink /></div>
      </header>
      <Feed />
      <AddPostButton />
    </div>
  );
}
