import Chip from '../ui/Chip';
import { Field, Input, Select } from '../ui/Field';
import { LOST_CATEGORIES, LOST_KIND_ENTRIES } from '../../constants/postTypes';
import type { LostFormValues } from '../../types/post';

interface Props {
  value: LostFormValues;
  onChange: <K extends keyof LostFormValues>(key: K, value: LostFormValues[K]) => void;
}

export default function LostItemFields({ value: o, onChange }: Props) {
  return (
    <fieldset className="grid gap-3 rounded-xl border border-slate-200 p-3 dark:border-slate-700">
      <legend className="px-1.5 text-xs text-slate-500">Item details</legend>

      <div className="flex flex-wrap gap-2">
        {LOST_KIND_ENTRIES.map(([key, label]) => (
          <Chip key={key} active={o.kind === key} onClick={() => onChange('kind', key)}>
            {label}
          </Chip>
        ))}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Category">
          <Select value={o.category} onChange={(e) => onChange('category', e.target.value)}>
            {LOST_CATEGORIES.map((x) => <option key={x}>{x}</option>)}
          </Select>
        </Field>
        <Field label="Date">
          <Input type="date" value={o.date} onChange={(e) => onChange('date', e.target.value)} />
        </Field>
        <Field label="Place">
          <Input value={o.place} onChange={(e) => onChange('place', e.target.value)} />
        </Field>
        <Field label="Contact phone">
          <Input value={o.contactPhone} onChange={(e) => onChange('contactPhone', e.target.value)} />
        </Field>
      </div>
    </fieldset>
  );
}
