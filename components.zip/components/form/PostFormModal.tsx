import Modal, { ModalHeader } from '../ui/Modal';
import Button from '../ui/ButtonForm';
import Alert from '../ui/Alert';
import { Field, Input, Textarea } from '../ui/Field';
import PostTypePicker from './PostTypePicker';
import CarpoolFields from './CarpoolFields';
import LostItemFields from './LostItemFields';
import { usePostForm } from '../../hooks/usePostForm';
import type { CreatePostPayload } from '../../types/post';

interface Props {
  onClose: () => void;
  onSubmit: (payload: CreatePostPayload) => Promise<void>;
}

export default function PostFormModal({ onClose, onSubmit }: Props) {
  const { values: f, set, setSub, saving, error, submit } = usePostForm({
    onSubmit,
    onDone: onClose,
  });

  return (
    <Modal onClose={onClose}>
      <form onSubmit={submit} className="grid gap-4">
        <ModalHeader onClose={onClose}>
          <h2 className="text-xl font-bold">New post</h2>
        </ModalHeader>

        <PostTypePicker value={f.type} onChange={(v) => set('type', v)} />

        <Field label="Title">
          <Input required maxLength={150} value={f.title} onChange={(e) => set('title', e.target.value)} />
        </Field>
        <Field label="Description">
          <Textarea required rows={4} maxLength={5000} value={f.description}
            onChange={(e) => set('description', e.target.value)} />
        </Field>

        {f.type === 'covoiturage' && (
          <CarpoolFields value={f.covoiturage} onChange={(k, v) => setSub('covoiturage', k, v)} />
        )}
        {f.type === 'objet_perdu' && (
          <LostItemFields value={f.objetPerdu} onChange={(k, v) => setSub('objetPerdu', k, v)} />
        )}

        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Location (optional)">
            <Input value={f.location} onChange={(e) => set('location', e.target.value)} />
          </Field>
          <Field label="Tags (comma separated)">
            <Input placeholder="tunis, weekend" value={f.tags} onChange={(e) => set('tags', e.target.value)} />
          </Field>
        </div>
        <Field label="Image URLs (one per line)">
          <Textarea rows={2} value={f.images} onChange={(e) => set('images', e.target.value)} />
        </Field>

        {error && <Alert>{error}</Alert>}

        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={saving}>{saving ? 'Publishing…' : 'Publish'}</Button>
        </div>
      </form>
    </Modal>
  );
}
