import { Field, Input } from '../ui/Field';
import type { CarpoolFormValues } from '../../types/post';

interface Props {
  value: CarpoolFormValues;
  onChange: <K extends keyof CarpoolFormValues>(key: K, value: CarpoolFormValues[K]) => void;
}

export default function CarpoolFields({ value: c, onChange }: Props) {
  return (
    <fieldset className="grid gap-3 rounded-xl border border-slate-200 p-3 dark:border-slate-700">
      <legend className="px-1.5 text-xs text-slate-500">Ride details</legend>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="From">
          <Input required value={c.departure} onChange={(e) => onChange('departure', e.target.value)} />
        </Field>
        <Field label="To">
          <Input required value={c.destination} onChange={(e) => onChange('destination', e.target.value)} />
        </Field>
        <Field label="Departure">
          <Input required type="datetime-local" value={c.departureDate}
            onChange={(e) => onChange('departureDate', e.target.value)} />
        </Field>
        <Field label="Seats">
          <Input type="number" min={1} max={8} value={c.seats}
            onChange={(e) => onChange('seats', e.target.value)} />
        </Field>
        <Field label="Price (TND)">
          <Input type="number" min={0} value={c.price}
            onChange={(e) => onChange('price', e.target.value)} />
        </Field>
        <Field label="Contact phone">
          <Input value={c.contactPhone} onChange={(e) => onChange('contactPhone', e.target.value)} />
        </Field>
      </div>
    </fieldset>
  );
}
