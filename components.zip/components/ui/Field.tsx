import type {
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
} from 'react';

export const controlClass =
  'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-normal text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100';

interface FieldProps {
  label: string;
  className?: string;
  children: ReactNode;
}

export function Field({ label, className = '', children }: FieldProps) {
  return (
    <label className={`grid gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 ${className}`}>
      <span>{label}</span>
      {children}
    </label>
  );
}

export const Input = ({ className = '', ...props }: InputHTMLAttributes<HTMLInputElement>) => (
  <input className={`${controlClass} ${className}`} {...props} />
);

export const Textarea = ({
  className = '',
  ...props
}: TextareaHTMLAttributes<HTMLTextAreaElement>) => (
  <textarea className={`${controlClass} ${className}`} {...props} />
);

export const Select = ({ className = '', ...props }: SelectHTMLAttributes<HTMLSelectElement>) => (
  <select className={`${controlClass} ${className}`} {...props} />
);
